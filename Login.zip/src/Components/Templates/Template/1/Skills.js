import React from 'react'

const Skills = () => {
    return (
        <div class="rela-block page">
            <div class="side-bar">
                <p class="rela-block caps side-header">Expertise</p>
                <p class="rela-block list-thing">HTML</p>
                <p class="rela-block list-thing">CSS (Stylus)</p>
                <p class="rela-block list-thing">JavaScript & jQuery</p>
                <p class="rela-block list-thing">Killer Taste</p>
            </div>
        </div>
    )
}

export default Skills
